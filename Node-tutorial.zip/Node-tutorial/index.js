const color = require('colors');
console.log('Hello Sanu'.green);

console.log("Set BackGround Blue".bgBlue);

console.log("Learning Node Js".gray);

const myDate = new Date();
console.log(typeof(myDate));
let object = myDate;

do {
  console.log("Learning ProtoType in JavaScript".bgWhite);  
  object = Object.getPrototypeOf(object);
  console.log(object);
} while (object);


