const person = {
    age:32,
    name:"Sanu"
};


const readOnly = ['cardNo', 'cardName','color'];

function add(key,val){ console.log("Something added", {key, val});}

const p = new Proxy({}, {
  set(target, key, val){
    console.time(">>add");
    add(key, val)
    console.timeEnd(">>add");

    target[key]=val
  },
  get(target, key){
    if(readOnly.includes(key)){ console.error("You area accesing private key", key); return "READ ONLY"; }
    return target[key];
  }

});


p.age = 30;
p.cardNo= 12345;
p.color="Red";


setTimeout(()=>{ console.table(p) }, 1000)
setTimeout(()=>{ console.warn(p) }, 2000)
setTimeout(()=>{ console.log(p.cardNo) }, 1000)
setTimeout(()=>{ console.log(p.color) }, 1000)

