let captcha_gen = () => {

    const randomNumber = (min, max) => {
        return (Math.floor(Math.random() * (max - min) + min));
    }
    let special = ['!', '#', '$', '%', '&', '*', '?', '@'];
    function arrange(text) {
        const result = [...text].sort(() => Math.random() - 0.5).join("");
        return result;
    }
    let val = '';

    for (let i = 0; i < 2; i++) {
        val = val + String.fromCharCode(randomNumber(65, 90));
        val = val + String.fromCharCode(randomNumber(97, 122));
        val = val + randomNumber(0, 9);
        val = val + special[randomNumber(0, (special.length - 1))];
    }
    console.log(val);
    const Captch = arrange(val);
    console.log(`Captch is Created : ${Captch}`);
}

captcha_gen();
