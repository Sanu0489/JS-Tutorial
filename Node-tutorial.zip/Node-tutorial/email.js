var nodeMailer = require("nodemailer");
var transport = nodeMailer.createTransport({
  service: 'gmail',
  secure: false,
  requireTLS: true,
  auth: {
    user: "subhransu.porel@gmail.com",
    pass: "bbbrkloxiwdjgkjk",
  },
});

var mailOptions = {
  from: "subhransu.porel@gmail.com", // Sender address
  to: "sanu0489@gmail.com", // List of recipients
  subject: "Test Mail from Node JS", // Subject line
  text: "Hello Dada, How are you?? " // Plain text body
};

transport.sendMail(mailOptions, function (err, info) {
  if (err) {
    console.log(err);
  } else {
    console.log("Email Has been Sent Succesfully", info.response);
  }
});

