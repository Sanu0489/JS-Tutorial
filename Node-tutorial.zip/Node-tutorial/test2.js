async function test2(){
    await new Promise(resolve=>{
        setTimeout(()=>{
            console.log('Hello');
            resolve();
        },5000)
    })
    console.log('World');
}
test2();
console.log('Keep Patience, It is an asynchronous operation');