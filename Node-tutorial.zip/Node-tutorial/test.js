
async function callAPI() {
    let res = await fetch('https://jsonplaceholder.typicode.com/users');
    if (res.ok) {
        const data = await res.json();
        console.log(res);
        console.log(data);
    }
}

const response = callAPI();
