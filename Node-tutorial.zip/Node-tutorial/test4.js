const color = require('colors');
let myObj = {'name':'Sanu',age:32,'profession':'IT'}
let size = Object.keys(myObj).length;
console.log(size);
let check = Object.hasOwn(myObj,'ages');
console.log(check);

function getName(fname,lname){
  console.log(`My name is ${fname} ${lname}`);
}

console.log(getName.length);
const str = "Ramayan";
console.log(str.length);

const marks = [20, 23, 19, 17, 38];
const names = ["Sanu","Bristi","Arpita","Arjya","Dona","Mampu"];
console.log(typeof(marks));
console.log(Array.isArray(marks));
console.log(marks.length);
console.log(myObj.length);

let x = null;
console.log(typeof(x));
console.log(typeof(getName));

const arr = [10, 4, 7, 8, 4, 6, 2, 4, 3, 10, 8, 9, 7, 6, 5];
console.log(`Length of Original Array is : ${arr.length}`);

const unique = [...new Set(arr)];
console.log(`unique array is : ${unique}`);
console.log(`No of unique elements are : ${unique.length}`);


console.log(unique.__proto__);
let object = unique;

do {
  console.log("Learning ProtoType in JavaScript".bgWhite);  
  object = Object.getPrototypeOf(object);
  console.log(object);
} while (object);

console.log((myObj.__proto__).__proto__);



